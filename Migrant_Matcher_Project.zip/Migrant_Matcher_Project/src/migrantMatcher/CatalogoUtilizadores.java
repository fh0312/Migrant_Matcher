package migrantMatcher;

public class CatalogoUtilizadores {

	public CatalogoUtilizadores() {
		// TODO Auto-generated constructor stub
	}

}
