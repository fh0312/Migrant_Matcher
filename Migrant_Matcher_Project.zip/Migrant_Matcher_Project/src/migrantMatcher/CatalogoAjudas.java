package migrantMatcher;

public class CatalogoAjudas {
	
	public CatalogoAjudas() {
		//TODO
	}
}
