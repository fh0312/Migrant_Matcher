package migrantMatcher;

public class CatalogoRegioes {

	public CatalogoRegioes() {
		// TODO Auto-generated constructor stub
	}

}
