package migrantMatcher;



public class MigrantMatcher {
	public MigrantMatcher() {
		//TODO
		}
	
}
