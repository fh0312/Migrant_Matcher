package handlers;

public class RegistaMigranteHandler {

	public RegistaMigranteHandler() {
		// TODO Auto-generated constructor stub
	}

}
