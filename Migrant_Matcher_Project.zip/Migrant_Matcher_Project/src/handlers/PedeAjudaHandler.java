package handlers;

public class PedeAjudaHandler {

	public PedeAjudaHandler() {
		// TODO Auto-generated constructor stub
	}

}
