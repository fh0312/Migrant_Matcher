package handlers;

public class AdcionarAjudaHandler {

	public AdcionarAjudaHandler() {
		// TODO Auto-generated constructor stub
	}

}
